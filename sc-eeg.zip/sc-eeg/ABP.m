function [ xRec,sRec ] = ABP( meas,S,D)
         
       

y = meas; clear meas
Phi = S; clear S
Omega = D; clear D

[M N]=size(Phi);

    cvx_begin
      variable xRec(N,1);
      minimize( norm(Omega*xRec,1));
      subject to
         y == Phi*xRec;
   cvx_end
   xRec=xRec./norm(xRec,2);
   sRec = Omega*xRec;
    
    end
    
    
           







