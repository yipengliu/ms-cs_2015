function [ xRec,sRec,iter ] = GAP( meas,S,D)
%GAP Summary of this function goes here
%   IN:
%   y = measured signal (m x 1)
%   M = measuremnet matrix (m x d)
%
%   OUT:
%   xRec = reconstructed signal

%   Sources:
%
%   The Cosparse Analysis Model and Algorithms
%   S. Nam , M. E. Daviesb , M. Eladc , R. Gribonval
%   Preprint submitted to Elsevier, June 27, 2011
%
%   COSPARSE ANALYSIS MODELING – UNIQUENESS AND ALGORITHMS
%   Sangnam Nam, Michael E. Davies, Michael Elad, R ́imi Gribonval
%   2011

% change variable names
y = meas; clear meas
M = S; clear S
[m,d] = size(M);
M2 = M'*M; % precalculation for faster performance
My = M'*y; %clear M y % precalculation for faster performance
omega = D; clear D
amount = 10;
t = 0.8;

p = size(omega,1);
lambda = 5e-2;

% Initialize
k=0;
Kmax = floor((p-amount)/amount);
% ts = tic;
% xCur = inv(M2 + lambda*omega' * omega) * My;
xCur = (M2 + lambda*omega' * omega) \ My; % faster alternative
% toc(ts)

% figure
% plot(xCur)
% drawnow

% Iterate
while k < Kmax
    k = k + 1;
    xPrev = xCur; clear xCur
    a = omega*xPrev;
%     amount = sum(a > t*max(a));
%     amount = 20;
    [alfa,alfaPos] = maxN(a,amount,'abs');
    supp = 1:size(omega,1);
    supp(alfaPos) = 0;
    supp = supp(supp ~= 0);
    omega = omega(supp,:);
%     ts = tic;
%     xCur = inv(M2 + lambda*omega' * omega) * My;
    xCur = (M2 + lambda*omega' * omega) \ My; % faster alternative
%     toc(ts)
    
%     plot(xCur)
%     drawnow
    
    % Norm indicates difference between current and previous result
    if k > 1
        prevNorm = refNorm;
    end
    % Norm indicates difference between current and previous result
    refNorm = abs(1 - norm(xCur)/norm(xPrev));
    
    if k > 1 
        if refNorm > prevNorm
            xRec = xPrev;
            break
        end
    end
    
end

xRec = xCur;

iter = k;

sRec = omega*xRec;

end

