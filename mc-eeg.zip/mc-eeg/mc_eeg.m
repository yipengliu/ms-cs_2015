clear all; close all; clc; cvx_quiet(true);

%% initial parameter setting: the performance can be evalued with different
load('chb01_031_edfm.mat')

signal=val';

Data=signal(1:1:end,:);


% DATA=Data';
% temp=vec(Data);


[L Nc]=size(Data);
for n=1:Nc
    Data(:,n)=Data(:,n)./norm(Data(:,n));
end
% data_channel=vec(Data');
% plot(data_channel(1:1000))

N=50;
Q=floor(L/N);
Qmax=30;
if Q>Qmax;  
   Q=Qmax;
end

%% dcitionaries
        
[DaubWav,NBVECT,LST,LONGS] = wmpdictionary(N,'lstcpt',{'sym10'});
Tv1=toeplitz([1;zeros(N-1,1)],[[1;-1];zeros(N-2,1)]);
TV1=toeplitz([1;zeros(Nc*N-1,1)],[[1;-1];zeros(Nc*N-2,1)]);
F=exp((-j*2*pi/(N*Nc))*(0:N*Nc-1)'*(0:N*Nc-1));
Csn=real(F);
Tv2=Tv1*Tv1;
TV2=TV1*TV1;
Tv4=Tv2*Tv2;
Tv6=Tv2*Tv4;
Tv8=Tv4*Tv4;
Psi = DaubWav;
[N R]=size(Psi);
Omega = Tv2;
        
for indexR=1:R
    Psi(:,indexR) = Psi(:,indexR)./norm(Psi(:,indexR));
end        
% for indexN=1:N
%     Omega(:,indexN) = Omega(:,indexN)./norm(Omega(:,indexN));
% end

for q=1:Q
    for p=1:10
        [q p]  
        
    X=Data(((q-1)*N+1):(q*N),:);
    X=X./norm(X,'fro');
%     for nc=1:Nc
%         X(:,nc)=X(:,nc)./norm(X(:,nc),2);
%     end
    M=floor(p*(0.1*N));  
    Phi = randn(M,N);        
        for n=1:N
            Phi(:,n)=Phi(:,n)./norm(Phi(:,n));
        end        
   Y=Phi*X;
    for nc=1:Nc
        Y(:,nc)=Y(:,nc)./norm(Y(:,nc),2);
    end

    
    %% signal recovery
    
    % SOMP
    stime1=cputime;
    [ XRec1,ThetaRec1,Iter1 ] = SOMMP( Y,Phi,Psi );
    CT(1,p,q)=cputime-stime1;
    XRec1=XRec1./norm(XRec1,'fro');
    E1(1,p,q)=sum(sum(X-XRec1));
    E2(1,p,q)=norm(X-XRec1,'fro');
    
    for nc=1:Nc
        temp0=X(:,nc); temp1=XRec1(:,nc);
        temp0=temp0./norm(temp0); temp1=temp1./norm(temp1);
        cor1(nc,1)=(temp0'*temp1);        
    end
    COR(1,p,q)=mean(cor1);

    
    % BSBLEM
    stime2=cputime;
    for nc=1:Nc        
        [ xRec2,thetaRec2,iter2 ] = BSBLEM( Y(:,nc),Phi,Psi );
        XRec2(:,nc)=xRec2;
    end
    CT(2,p,q)=cputime-stime2;
    XRec2=XRec2./norm(XRec2,'fro');
    E1(2,p,q)=sum(sum(X-XRec2));
    E2(2,p,q)=norm(X-XRec2,'fro');
    
    for nc=1:Nc
        temp0=X(:,nc); temp2=XRec2(:,nc);
        temp0=temp0./norm(temp0); temp2=temp2./norm(temp2);
        cor2(nc,1)=(temp0'*temp2);        
    end
    COR(2,p,q)=mean(cor2);
    
    
       % GAP
    for nc=1:Nc
        stime3=cputime;
        [ xRec3,thetaRec3,Iter3 ] = GAP( Y(:,nc),Phi,Omega );
         XRec3(:,nc)=xRec3;
    end
    CT(3,p,q)=cputime-stime3;
    XRec3=XRec3./norm(XRec3,'fro');
    E1(3,p,q)=sum(sum(X-XRec3));
    E2(3,p,q)=norm(X-XRec3,'fro');
    
    for nc=1:Nc
        temp0=X(:,nc); temp3=XRec3(:,nc);
        temp0=temp0./norm(temp0); temp3=temp3./norm(temp3);
        cor3(nc,1)=(temp0'*temp3);        
    end
    COR(3,p,q)=mean(cor3);
     


    % SGAP
    stime4=cputime;
    [ XRec4,ThetaRec4,Iter4 ] = SGAP( Y,Phi,Omega );
    CT(4,p,q)=cputime-stime4;
    XRec4=XRec4./norm(XRec4,'fro');
    E1(4,p,q)=sum(sum(X-XRec4));
    E2(4,p,q)=norm(X-XRec4,'fro');
    
    for nc=1:Nc
        temp0=X(:,nc); temp4=XRec4(:,nc);
        temp0=temp0./norm(temp0); temp4=temp4./norm(temp4);
        cor4(nc,1)=(temp0'*temp4);        
    end
    COR(4,p,q)=mean(cor4);

    
    
    % SPTV-nuclear norm: admm
    stime5=cputime;
    rou51=1;rou52=1;rou53=1;
    U51=ones(N,Nc); U52=ones(N,Nc); U53=(-2)*ones(N,Nc);
    Z5=zeros(N,Nc);
 
    for admm8=1:10
        cvx_begin
          variable X51(N,Nc);
          minimize( norm(TV2*vec(X51),1) + norm(F*vec(X51'),1) + rou51/2*norm(X51-Z5+U51,'fro'));
       cvx_end       
       cvx_begin
          variable X52(N,Nc);
          minimize( norm_nuc(X52) + rou52/2*norm(X52-Z5+U52,'fro'));
       cvx_end
       cvx_begin
          variable X53(N,Nc);
          minimize( norm(Y-Phi*X53,'fro') + rou53/2*norm(X53-Z5 + U53,'fro'));
       cvx_end
       
        Z5 = 1/3*(X51+X52+X53);
       
       U51 = U51 + rou51*(X51-Z5);
       U52 = U52 + rou52*(X52-Z5); 
       U53 = U53 + rou53*(X53-Z5);        
      
    end
    XRec5=Z5;
    CT(5,p,q)=cputime-stime5;
    XRec5=XRec5./norm(XRec5,'fro');
    E1(5,p,q)=sum(sum(X-XRec5));
    E2(5,p,q)=norm(X-XRec5,'fro');     
    for nc=1:Nc
        temp0=X(:,nc); temp5=XRec5(:,nc);
        temp0=temp0./norm(temp0); temp5=temp5./norm(temp5);
        cor5(nc,1)=(temp0'*temp5);        
    end
    COR(5,p,q)=mean(cor5); 
 


    
        % TV-NUC
    stime6=cputime;
    cvx_begin
      variable XRec6(N,Nc);
      minimize( norm(TV2*vec(XRec6),1) + norm_nuc(XRec6));
      subject to
         Y == Phi*XRec6;
   cvx_end
    CT(6,p,q)=cputime-stime6;
    XRec6=XRec6./norm(XRec6,'fro');
    E1(6,p,q)=sum(sum(X-XRec6));
    E2(6,p,q)=norm(X-XRec6,'fro'); 
    
    for nc=1:Nc
        temp0=X(:,nc); temp6=XRec6(:,nc);
        temp0=temp0./norm(temp0); temp6=temp6./norm(temp6);
        cor6(nc,1)=(temp0'*temp6);        
    end
    COR(6,p,q)=mean(cor6);
    
    
      

      % NUC
    stime7=cputime;
    cvx_begin
      variable XRec7(N,Nc);
      minimize(norm_nuc(XRec7));
      subject to
      Y == Phi*XRec7;
   cvx_end
    CT(7,p,q)=cputime-stime7;
    XRec7=XRec7./norm(XRec7,'fro');
    E1(7,p,q)=sum(sum(X-XRec7));
    E2(7,p,q)=norm(X-XRec7,'fro');     
    for nc=1:Nc
        temp0=X(:,nc); temp7=XRec7(:,nc);
        temp0=temp0./norm(temp0); temp7=temp7./norm(temp7);
        cor7(nc,1)=(temp0'*temp7);        
    end
    COR(7,p,q)=mean(cor7);
%     
%     



       % TV-NUC: ADMM
    stime8=cputime;
    rou81=1;rou82=1;rou83=1;
    U81=ones(N,Nc); U82=ones(N,Nc); U83=(-2)*ones(N,Nc);
    Z8=zeros(N,Nc);
 
    for admm8=1:10
        cvx_begin
          variable X81(N,Nc);
          minimize( norm(TV2*vec(X81),1) +rou81/2*norm(X81-Z8+U81,'fro'));
       cvx_end       
       cvx_begin
          variable X82(N,Nc);
          minimize( norm_nuc(X82) + rou82/2*norm(X82-Z8+U82,'fro'));
       cvx_end
       cvx_begin
          variable X83(N,Nc);
          minimize( norm(Y-Phi*X83,'fro') + rou83/2*norm(X83-Z8 + U83,'fro'));
       cvx_end
       
        Z8 = 1/3*(X81+X82+X83);
       
       U81 = U81 + rou81*(X81-Z8);
       U82 = U82 + rou82*(X82-Z8); 
       U83 = U83 + rou83*(X83-Z8);        
      
    end
    XRec8=Z8;
    CT(8,p,q)=cputime-stime8;
    XRec8=XRec8./norm(XRec8,'fro');
    E1(8,p,q)=sum(sum(X-XRec8));
    E2(8,p,q)=norm(X-XRec8,'fro'); 
    
    for nc=1:Nc
        temp0=X(:,nc); temp8=XRec8(:,nc);
        temp0=temp0./norm(temp0); temp8=temp8./norm(temp8);
        cor8(nc,1)=(temp0'*temp8);        
    end
    COR(8,p,q)=mean(cor8);

    
           
    end
end








