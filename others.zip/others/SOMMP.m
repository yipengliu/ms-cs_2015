function [ xRec,sRec,iter ] = SOMMP( meas,S,D )
% Reconstruct using the OMP algorithm
%   Input:  meas = measured matrix (measurements in columns)
%           S = sensing matrix (size: MxN)
%           D = dictionary (size: NxN
%   Output: xRec = reconstructed signal
%
%   Based on:
%   SIMULTANEOUS SPARSE APPROXIMATION VIA GREEDY PURSUIT
%   J. A. Tropp, A. C. Gilbert M. J. Strauss
%   IEEE, 2005

% Change variables
phi = S*D;
[m,N] = size(phi);
phiOmega = [];
u = meas; % measurement
uAmount = size(u,2);

% Initialize
omega = []; % support
r = u; % residual
coeffEst = zeros(N,1); % coefficient estimate
k = 1;
refNorm = inf;
amount = 4; % indices selected per iteration, must be multiple of amouunt of signals
iter = 0;

% h = figure;

% do until the norm of the residual is small enough (compared to the
% norm of the measurement
% while norm(r,2)/norm(u,2) > 0.01
while refNorm > 0.05
    
    iter = iter + 1;
    
    % find best approximating column in dictionary
    [maxVal,n] = maxN(sum(abs(phi'*r),2),amount,'normal');
    n = n';
    omega = [omega n];
    
    % orthogonal projector P
    phiOmega(:,k:k+amount-1) = phi(:,n);
    
    % Set columns in phi to zero to avoid reselection
    phi(:,n) = 0;
    
    % backslash operator returns the least squares solution of the
    % system of linear equations phiOmega*x = u
    x = phiOmega \ u;
    
%     plot(real(x(:,1)))
%     title('Current')
%     drawnow

    % compute residual
    r = u - phiOmega*x;
    
    % calculate max norm ratio
    curNorm = sqrt(sum(r.^2,1)) ./ sqrt(sum(u.^2,1));
    refNorm = max(curNorm);
    
    % increment k
    k = k+amount;
    
end

% Create coefficient vector
coeff = zeros(N,uAmount);
% coeff(omega,:) = x;
coeff(omega,:) = x;

% Calculate reconstructed signal
xRec = D*coeff;

sRec = coeff;

end
