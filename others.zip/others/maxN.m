function [ maxVal,maxInd ] = maxN( vec,n,mode )
%FINDLARGEST Find the n largest values in a vector
%   INPUT
%   vec = input vector
%   n = how many values should be selected
%   mdoe = 'normal' or 'abs', 'abs' selects n values with the biggest
%           absolute value
%   OUTPUT
%   maxVal = values
%   maxInd = indices, locations in the vector

[d1,d2] = size(vec);
if d1 == 1 && d2 > 1 % horizontal vector
    vec = vec'; % make vertical
elseif d1 == 1 && d2 == 1 % vec is a scalar
    error('Input is a scalar, should be a vector');
elseif d1 > 1 && d2 > 1 % vec is a matrix
    error('Input is a matrix, should be a vector');
end

if(strcmp(mode,'abs'))
    [sorted,ind] = sort(abs(vec),1,'descend');
    maxInd = ind(1:n);
    maxVal = vec(maxInd);
else
    [sorted,ind] = sort(vec,1,'descend');
    maxVal = sorted(1:n);
    maxInd = ind(1:n);
end

end

