function [ xRec,sRec,iter ] = SGAP( meas,S,D)
%GAP Summary of this function goes here
%   IN:
%   y = measured signal (m x 1)
%   M = measuremnet matrix (m x d)
%
%   OUT:
%   xRec = reconstructed signal

%   Sources:
%
%   The Cosparse Analysis Model and Algorithms
%   S. Nam , M. E. Daviesb , M. Eladc , R. Gribonval
%   Preprint submitted to Elsevier, June 27, 2011
%
%   COSPARSE ANALYSIS MODELING – UNIQUENESS AND ALGORITHMS
%   Sangnam Nam, Michael E. Davies, Michael Elad, R ́imi Gribonval
%   2011

% change variable names
y = meas; clear meas
M = S; clear S
[m,d] = size(M);
M2 = M'*M; % precalculation for faster performance
My = M'*y; %clear M y % precalculation for faster performance
omega = D; clear D
amount = 10;
t = 0.8;

p = size(omega,1);
lambda = 5e-2;

% Initialize
k=0;
Kmax = floor((p-amount)/amount);
xCur = pinv(M2 + lambda*omega' * omega) * My;
% xCur = (M2 + lambda*omega' * omega) \ My; % faster alternative

% h = figure;
% subplot(211)
% plot(real(xCur(:,1)))
% title('CH1')
% subplot(212)
% plot(real(xCur(:,2)))
% title('CH2')
% drawnow

% Iterate
while k < Kmax
    
    k = k + 1;
    xPrev = xCur; clear xCur
    a = omega*xPrev;
%     amount = sum(sum(a > t*max(max(a))));
    [alfa,alfaPos] = maxN(sum(a,2),amount,'abs');
    supp = 1:size(omega,1); 
    supp(alfaPos) = 0;
    supp = supp(supp ~= 0);
    omega = omega(supp,:);
     xCur = pinv(M2 + lambda*omega' * omega) * My;
%     xCur = (M2 + lambda*omega' * omega) \ My; % faster alternative
    
%     subplot(211)
%     plot(real(xCur(:,1)))
%     hold on
%     plot(real(xPrev(:,1)),'-r')
%     title('CH1')
%     subplot(212)
%     plot(real(xCur(:,2)))
%     hold on
%     plot(real(xPrev(:,2)),'-r')
%     title('CH2')
%     drawnow
    
    % Norm indicates difference between current and previous result
    if k > 1
        prevNorm = refNorm;
    end
    refNorm = abs(ones(1,size(y,2)) - sqrt(sum(xCur.^2,1)) ./ sqrt(sum(xPrev.^2,1)));
    
    if k > 1 
        if sum(refNorm > prevNorm) > 0
            xRec = xPrev;
            break
        end
    end

%     if max(refNorm) < 0.025
%         xRec = xCur;
%         break
%     end
    
end

xRec = xCur;

iter = k;

sRec = omega*xRec;

end

