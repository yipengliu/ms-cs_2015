function [ xRec,sRec,iter ] = BSBLEM( meas,S,D)
%%BSBLBO Frontend for the BSBL-BO algorithm in BSBL_BO.m
% Block Sparse Bayesian Learning - Bound Optimization method

addpath('./alg/BSBLbackend');

Phi = S*D;
y = meas;
blkLength = 10;
signalSize = size(Phi,2);
blkStartLoc = 1:blkLength:signalSize;

LearnLambda = 2;
%   LearnLambda : (1) If LearnLambda = 1, use the lambda learning rule for very LOW SNR cases
%                       (SNR<10dB) (using lambda=std(y)*1e-2 or user-input value as initial value)
%                 (2) If LearnLambda = 2, use the lambda learning rule for medium noisy cases 
%                       (SNR>10dB) (using lambda=std(y)*1e-2 or user-input value as initial value)
%                 (3) If LearnLambda = 0, do not use the lambda learning rule 
%                     ((using lambda=1e-14 or user-input value as initial value)

% [varargin values -- in most cases you can use the default values]
LearnType = 1;
%  'LEARNTYPE'    : LEARNTYPE = 0: Ignore intra-block correlation
%                   LEARNTYPE = 1: Exploit intra-block correlation 
%                 [ Default: LEARNTYPE = 1 ]
Prune_Gamma = 1e-3;
%  'PRUNE_GAMMA'  : threshold to prune out small gamma_i 
%                   (generally, 10^{-3} or 10^{-2})
Lambda = 1e-14;
%  'LAMBDA'       : user-input value for lambda
%                  [ Default: LAMBDA=1e-14 when LearnLambda=0; LAMBDA=std(y)*1e-2 in noisy cases ]
Max_iters = 150;
%  'MAX_ITERS'    : Maximum number of iterations.
%                 [ Default value: MAX_ITERS = 800 ]
Epsilon = 1e-4;
%  'EPSILON'      : Solution accurancy tolerance parameter 
%                 [ Default value: EPSILON = 1e-8   ]
Print = 0;
%  'PRINT'        : Display flag. If = 1: show output; If = 0: supress output
%                 [ Default value: PRINT = 0        ]

'start'
xRec = BSBL_EM(Phi, y, blkStartLoc, LearnLambda, 'EPSILON',Epsilon);
'stop'
xRec = xRec.x;
xRec = real(D*xRec);

iter = xRec.count;

sRec = [];

end